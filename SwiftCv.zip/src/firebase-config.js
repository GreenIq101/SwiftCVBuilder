// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyBgsdaWhYJu8P0h7ozwjVqnumsF_OFuFdk",
  authDomain: "swiftcv-aeb40.firebaseapp.com",
  projectId: "swiftcv-aeb40",
  storageBucket: "swiftcv-aeb40.firebasestorage.app",
  messagingSenderId: "1031759867887",
  appId: "1:1031759867887:web:d616edc674a50b32ab501a",
  measurementId: "G-Z9B0ZX43GT"
}

// Initialize Firebase
initializeApp(firebaseConfig);
