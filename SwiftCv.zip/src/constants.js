export const LOGO_PATH = require("./Img/logo.png");

